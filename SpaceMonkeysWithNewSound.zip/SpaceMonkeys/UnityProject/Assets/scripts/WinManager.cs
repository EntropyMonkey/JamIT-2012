using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class WinManager : MonoBehaviour
{
	public const string Tag = "MainCamera";

	public float PlayTime; // how long you play the game until you win
	float playedTime;
	public float PlayedTime
	{
		get
		{
			return playedTime;
		}
	}

	List<Player> players;

	// Use this for initialization
	void Start()
	{
		GameObject[] gos = GameObject.FindGameObjectsWithTag(PlayerSettings.Tag);
		players = new List<Player>();
		foreach (GameObject go in gos)
		{
			Player p = go.GetComponent<Player>();
			players.Add(p);
		}

		playedTime = 0;
	}

	// Update is called once per frame
	void Update()
	{
		playedTime += Time.deltaTime;
		if (playedTime >= PlayTime)
			WinGame();
	}

	void WinGame()
	{
		int currentMax = 0;
		int currentPoints = 0;
		// get playr with max points
		for (int i = 0; i < players.Count; i++)
		{
			if (players[i].points > players[currentMax].points)
			{
				currentPoints = players[i].points;
				currentMax = i;
			}
		}

		Time.timeScale = 0;

		if (currentPoints > 0)
			GetComponent<UI>().Winner = players[currentMax];
		else
			GetComponent<UI>().NoOneWins = true;
	}
}
