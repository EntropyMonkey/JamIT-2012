using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Player : MonoBehaviour
{
	static int nextFreeId = 0;

	public List<AudioClip> screamFiles;
	public AudioClip motorFileIdle;
	public AudioClip motorFileAccelerate;

	AudioSource[] audioSources;

	CharacterController characterController;

	public Vector2 Velocity = new Vector2(10, 0);

    public float DeathTimePenalty = 0.0f;// Changes to 2.0F on first death
    private float timeSinceDeath = 0F;
    private float boostSpeed = 8;
	public int id
	{
		get;
		private set;
	}

	public ChangingInput input
	{
		get;
		private set;
	}

	public PlayerSettings settings;

	public int points
	{
		get;
		set;
	}

    private bool dead = false;
    bool hasDiedYet = false;

	void Awake()
	{
		tag = PlayerSettings.Tag;
		gameObject.layer = LayerMask.NameToLayer(PlayerSettings.Tag);
		Physics.IgnoreLayerCollision(gameObject.layer, gameObject.layer);
	}

	// Use this for initialization
	void Start()
	{
		id = nextFreeId++;

		input = GetComponent<ChangingInput>();
		characterController = GetComponent<CharacterController>();

		points = 0;

		renderer.material.color = settings.Color;

		audioSources = GetComponents<AudioSource>();
		if (audioSources.Length < 2)
		{
			Debug.LogError("You need two audio sources on player " + id + ".");
		}

		audioSources[1].clip = motorFileIdle;
		audioSources[1].Play();
		audioSources[1].loop = true;
	}

	void Reset(Vector3 position)
	{
		transform.position = position;
	}

	public void Die(Vector3 cameraPosition, Camera cam)
	{
		if (!dead)
		{
			timeSinceDeath = 0;
			audioSources[0].clip = screamFiles[Random.Range(0, screamFiles.Count)];
			audioSources[0].Play();
		}
        dead = true;
	}

	// Update is called once per frame
	void Update()
	{
        if (!hasDiedYet && Camera.current != null)
        {
            hasDiedYet = true;
            Respawn();
        }




		timeSinceDeath += Time.deltaTime;	
        if (dead == true && timeSinceDeath > DeathTimePenalty)
        {
            Respawn();
        }
        else
		{
			if (characterController.isGrounded)
			{
				Velocity.y = 0;
				if (input.KeyDown(ChangingInput.KEYS.JUMP))
				{
					Velocity.y = settings.JumpSpeed;
				}
			}

			Velocity.x = 10;

            if(input.KeyDown(ChangingInput.KEYS.BOOST))
                Velocity.x += boostSpeed;
				
			Velocity.y -= settings.Gravity * Time.deltaTime;

			characterController.Move(new Vector3(Velocity.x * Time.deltaTime, Velocity.y * Time.deltaTime, 0));

			if (Input.GetKey(KeyCode.Space))
				Reset(new Vector3(0, 2, 0));
		}
	}

	void OnControllerColliderHit(ControllerColliderHit hit)
	{
		if (hit.normal.y < 0)
		{
			Velocity.y = 0;
		}
	}

    private void Respawn()
    {
		GameObject cam = GameObject.FindGameObjectWithTag("MainCamera");
		if(cam != null)
		{
	        Vector3 newPos = cam.transform.position;
	        newPos.x -= 5;
	        newPos.y = PlayerSettings.SpawnPositionY;
	        newPos.z = 0;
	
	        // only spawn over a platform
	        bool foundPlatform = false;
	        int loopCountdown = 10;
	        while (!foundPlatform)
	        {
	            RaycastHit hitInfo;
	            // if there is nothing below for 10m, take a new position
	            Physics.Raycast(newPos, Vector3.down, out hitInfo, 10.0f);
	
	            if (hitInfo.collider == null)
	            {
	                newPos.x += PlayerSettings.PlatformSize;
	            }
	            else foundPlatform = true;
	
	            if (loopCountdown-- <= 0)
	                break;
	        }

			dead = false;
			timeSinceDeath = 0F;
			DeathTimePenalty = 2.0f;
	        Reset(newPos);
		}
    }
}
