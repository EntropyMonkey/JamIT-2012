using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class InputChanger : MonoBehaviour {

    private static List<KeyCode> NormalKeys = new List<KeyCode>();

	public float changeJumpKeysAfter = 5; // seconds
	public float changeBoostKeysAfter = 1; // secconds

	float jumpKeyTimer, boostKeyTimer;

	// Use this for initialization
	void Start () {
        NormalKeys.Add(KeyCode.A);
        NormalKeys.Add(KeyCode.B);
        NormalKeys.Add(KeyCode.C);
        NormalKeys.Add(KeyCode.D);
        NormalKeys.Add(KeyCode.E);
        NormalKeys.Add(KeyCode.F);
        NormalKeys.Add(KeyCode.G);
        NormalKeys.Add(KeyCode.H);
        NormalKeys.Add(KeyCode.I);
        NormalKeys.Add(KeyCode.J);
        NormalKeys.Add(KeyCode.K);
        NormalKeys.Add(KeyCode.L);
        NormalKeys.Add(KeyCode.M);
        NormalKeys.Add(KeyCode.N);
        NormalKeys.Add(KeyCode.O);
        NormalKeys.Add(KeyCode.P);
        NormalKeys.Add(KeyCode.Q);
        NormalKeys.Add(KeyCode.R);
        NormalKeys.Add(KeyCode.S);
        NormalKeys.Add(KeyCode.T);
        NormalKeys.Add(KeyCode.U);
        NormalKeys.Add(KeyCode.V);
        NormalKeys.Add(KeyCode.X);
        NormalKeys.Add(KeyCode.Y);
        NormalKeys.Add(KeyCode.Z);
        NormalKeys.Add(KeyCode.W);

		jumpKeyTimer = boostKeyTimer = 0;

		ShuffleJumpKeys();
		ShuffleBoostKeys();
	}
	
	// Update is called once per frame
	void Update () 
	{
		jumpKeyTimer += Time.deltaTime;
		boostKeyTimer += Time.deltaTime;

		if (jumpKeyTimer > changeJumpKeysAfter)
		{
			jumpKeyTimer = 0;
			ShuffleJumpKeys();
			GetComponent<UI>().ShowJumpKeysChanged();
		}

		if (boostKeyTimer > changeBoostKeysAfter)
		{
			ShuffleBoostKeys();
			boostKeyTimer = 0;
		}
	}

    public static void ShuffleBoostKeys()
    {
		var unuseableKeys = new List<KeyCode>();
		for (int i = 0; i < ChangingInput.Instances.Count; ++i)
		{
			unuseableKeys.Add(ChangingInput.Instances[i].JumpKey);
			unuseableKeys.Add(ChangingInput.Instances[i].BoostKey);
		}
		var useableKeys = new List<KeyCode>(NormalKeys);
		useableKeys.RemoveAll(k => unuseableKeys.Contains(k));

		for (int i = 0; i < useableKeys.Count; ++i) //Randomize array
		{
			int newPos = Random.Range(0, useableKeys.Count);
			KeyCode otherKey = useableKeys[newPos];
			useableKeys[newPos] = useableKeys[i];
			useableKeys[i] = otherKey;
		}

		for (int i = 0; i < ChangingInput.Instances.Count; ++i) //Set new keys
		{
			ChangingInput.Instances[i].BoostKey = useableKeys[i];
		}
    }

	public static void ShuffleJumpKeys()
	{
		var unuseableKeys = new List<KeyCode>();
		for (int i = 0; i < ChangingInput.Instances.Count; ++i)
		{
			unuseableKeys.Add(ChangingInput.Instances[i].JumpKey);
			unuseableKeys.Add(ChangingInput.Instances[i].BoostKey);
		}

		var useableKeys = new List<KeyCode>(NormalKeys);
		useableKeys.RemoveAll(k => unuseableKeys.Contains(k));

		for (int i = 0; i < useableKeys.Count; ++i) //Randomize array
		{
			int newPos = Random.Range(0, useableKeys.Count);
			KeyCode otherKey = useableKeys[newPos];
			useableKeys[newPos] = useableKeys[i];
			useableKeys[i] = otherKey;
		}

		for (int i = 0; i < ChangingInput.Instances.Count; ++i) //Set new keys
		{
			ChangingInput.Instances[i].JumpKey = useableKeys[i];

		}
	}
}
