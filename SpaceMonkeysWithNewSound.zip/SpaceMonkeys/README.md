JamIT-2012
==========

It's a small running game for some players. The keys change.